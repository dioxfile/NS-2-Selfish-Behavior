#if __POWERPC__
#include "MW_TclStaticHeaderPPC"
#elif __CFM68K__
#include "MW_TclStaticHeaderCFM68K"
#else
#include "MW_TclStaticHeader68K"
#endif
